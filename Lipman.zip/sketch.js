function setup() {
  createCanvas(256, 256);
}

function draw() {
  background(112);
  strokeWeight(10);
  line(0, 0, 256, 256);
  line(256, 0, 0, 256);
  ellipse(28, 28, 40, 40);
  ellipse(128, 128, 80, 80);
  ellipse(228, 228, 40, 40);
  strokeWeight(1)
  fill(198);
  rect(113, 113, 30, 30);
  noFill();
  strokeWeight(10)
  strokeCap(PROJECT)
  line(26, 128, 230, 128)
  line(128, 26, 128, 230)
}