function setup() {
  createCanvas(1000, 1000);
  background(1);
  strokeWeight(5);
  noFill();
  frameRate(120)
  
  let canvasWidth = width;
  let canvasHeight = height;

  let angle = 0;
  let angleIncrement = radians(1); 

  draw = function() {
    let r = map(cos(angle), -1, 1, 0, 255);
    let g = map(cos(angle + radians(120)), -1, 1, 0, 255);
    let b = map(cos(angle + radians(240)), -1, 1, 0, 255); 

    stroke(r, g, b);
    if (mouseIsPressed) {
      let d = dist(pmouseX, pmouseY, mouseX, mouseY);
      line(pmouseX, pmouseY, mouseX, mouseY);
    }

    angle += angleIncrement;
    if (angle > TWO_PI) {
      angle = 0;
    }
  };

  keyPressed = function() {
    if (key === 'c' || key === 'C') {//PRESS C TO CLEAR DRAWINGS
      background(1);
    }
  };

  mouseWheel = function(event) {
    let brushSize = constrain(strokeWeight() + event.delta * 0.1, 1, 50);
    strokeWeight(brushSize);
    return false;
  };
}

new p5();
