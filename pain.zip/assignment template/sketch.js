var x1 = 425;
var y1 = 155;
var w1 = 20;
var h1 = 15;
var isColorChanging = false;
var lastMouseState = false;
let buttonX, buttonY, buttonSize = 15;
let actionPerformed = false;
let isSpacePressed = false;
let bsodX = 605;
let bsodY = 205;
let bsodWidth = 290;
let bsodHeight = 170;
let buttonX1 = 700;
let buttonY1 = 500;
let buttonWidth1 = 50;
let buttonHeight1 = 50;
let isMouseOverButton = false;
function setup() {
  createCanvas(1000, 1000);
  frameRate(120);
  buttonX = 625;
  buttonY = 390;
}
function draw() {
  noFill(255);
  beginShape();
  vertex(250, 225);
  vertex(250, 450);
  vertex(400, 550);
  vertex(550, 550);
  vertex(550, 150);
  vertex(400, 150);
  vertex(250, 225);
  endShape();
  beginShape();
  vertex(250, 250);
  vertex(400, 175);
  vertex(550, 175);
  endShape();
  beginShape();
  vertex(250, 400);
  vertex(400, 475);
  vertex(550, 475);
  endShape();
  line(400, 550, 400, 150);
  ellipse(475, 400, 125, 125);
  ellipse(475, 250, 125, 125);
  fill(200)
  rect(x1, y1, w1, h1);
  if (
    (mouseX > x1) &&
    (mouseX < x1 + w1) &&
    (mouseY > y1) &&
    (mouseY < y1 + h1)
  ) {
    if (mouseIsPressed && !lastMouseState) {
      isColorChanging = !isColorChanging;
    }
  }
  if (isColorChanging) {
    var redValue = sin(frameCount * 0.05) * 127 + 128;
    var greenValue = sin(frameCount * 0.05 + PI / 2) * 127 + 128;
    var blueValue = sin(frameCount * 0.05 + PI) * 127 + 128;
    fill(redValue, greenValue, blueValue);
  } else {
    fill(255);
  }
  ellipse(475, 400, 125, 125);
  ellipse(475, 250, 125, 125);
  fill(255)
  ellipse(475, 400, 100, 100);
  ellipse(475, 250, 100, 100);
  lastMouseState = mouseIsPressed;
  fill(dist(mouseX, mouseY, buttonX, buttonY) < buttonSize / 2 ? color(200, 0, 0) : 200);
  ellipse(buttonX, buttonY, buttonSize);
  if (mouseIsPressed && dist(mouseX, mouseY, buttonX, buttonY) < buttonSize / 2 && !actionPerformed) {
  fill(155)
  rect(605, 205, 290, 170)
  fill(0, 51, 204); // Blue
  rect(630, 220, 50, 50);
  fill(112, 173, 71); // Green
  rect(695, 220, 50, 50);
  fill(238, 28, 37); // Red
  rect(630, 285, 50, 50);
  fill(252, 209, 22); // Yellow
  rect(695, 285, 50, 50);
    actionPerformed = true;
  }
  {
  noFill()
  rect(600, 200, 300, 200)
  rect(605, 205, 290, 170)
  rect(725, 400, 50, 50)
  rect(650, 450, 200, 25)
  }
  rect(bsodX, bsodY, bsodWidth, bsodHeight);
  // Draw the red "Do Not Press" button
  fill(255, 0, 0); // Red button
  rect(buttonX1, buttonY1, buttonWidth1, buttonHeight1);
  // Toggle the BSOD screen with the button
  if (isSpacePressed && isMouseOverButton) {
    fill(0, 0, 255); // Blue background
    rect(bsodX, bsodY, bsodWidth, bsodHeight);
    fill(255); // White text
    textSize(20);
    textAlign(LEFT);
    text("Your PC ran into a problem", bsodX + 15, bsodY + 15, bsodWidth - 30, 40);
    textSize(16);
    text("Error code: 0x000001", bsodX + 15, bsodY + 55, bsodWidth - 30, 40);
  }
}
function keyPressed() {
  if (key === ' ' && isMouseOverButton) {
    isSpacePressed = !isSpacePressed;
    redraw(); // Redraw the canvas
  }
}
function keyReleased() {
  if (key === ' ') {
    // Redraw the canvas
    redraw();
  }
}
function mouseMoved() {
  isMouseOverButton = (mouseX > buttonX1 && mouseX < buttonX1 + buttonWidth1 &&
    mouseY > buttonY1 && mouseY < buttonY1 + buttonHeight1);
}
function mouseReleased() {
  actionPerformed = false;
}