let img1;
let img2;
let transparentImg;
let font;
function preload() {
  img1 = loadImage('image1.jpg');
  img2 = loadImage('image2.jpg');
  transparentImg = loadImage('pain and suffering.png');
  font = loadFont('zalgo.ttf');
  frameRate(120)
}
function setup() {
  createCanvas(1000, 1000);
  textFont(font)
}
function draw() {
  background(220);
  image(img1, pmouseX - 250, mouseY - 250, 500, 500);
  stroke(0);
  fill(255, 100, 200);
  textSize(40);
  text("Me when you", 500, 450, 360, 100);
  text("when you", 500, 750, 360, 100)
  image(img2, 500, 500, 200, 200);
  image(transparentImg, mouseX, mouseY + 60, 80, 80);
}